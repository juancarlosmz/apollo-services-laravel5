<?php
namespace App\Http\Controllers;
use App\Deposito;
use Illuminate\Http\Request;
use App\Http\Requests\DepositoRequest;
class DepositoController extends Controller{
    public function create(){
        //
    }
}
