<?php
namespace App\Http\Controllers;
use App\Ordenestado;
use Illuminate\Http\Request;
use App\Http\Requests\OrdenestadoRequest;
use Illuminate\Support\Facades\DB;
// Firebase conect
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
class OrdenestadoController extends Controller{
    public function show($id_firebase){
        // Firebaseb conect
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/expertify-3b3d4-firebase-adminsdk-l30jf-1e53428b24.json');
        $firebase = (new Factory)
            ->withServiceAccount($serviceAccount)
            ->withDatabaseUri('https://expertify-3b3d4.firebaseio.com/')
            ->create();
        $database = $firebase->getDatabase();
        // 
        // variables
        $userIdcomprador;
        $data = DB::table('ordenestados')
            ->join('ordencambiaestados', 'ordenestados.id', '=', 'ordencambiaestados.ordenestadoId')
            ->join('ordens', 'ordens.id', '=', 'ordencambiaestados.ordenId')
            ->join('transaccions', 'transaccions.ordenId', '=', 'ordens.id')
            ->join('usuarios', 'usuarios.id', '=', 'transaccions.userIdvendedor')
            ->select('ordens.id', 'ordens.numero', 'ordens.fechaentrega', 'ordens.total','transaccions.userIdcomprador', DB::raw('max(ordenestados.descripcion) as Estados'))
            //->where('ordenestados.id', '2')
            ->where('usuarios.id_firebase', $id_firebase)
            ->groupBy('ordens.id')
            ->havingRaw("COUNT(ordencambiaestados.ordenestadoId) = 2")
            ->orderBy('ordens.fechaentrega', 'DESC')
            ->get();               
        if($data){
            $arrayIds = array();
            foreach ($data as $key => $dt) {
                $userIdcomprador = DB::table('usuarios')
                    ->select('usuarios.id_firebase as userIdcomprador')
                    ->where('usuarios.id', $dt->userIdcomprador)
                    ->get();
                array_push($arrayIds, $userIdcomprador);    
            }
            $arrayData = array();
            // firebase
            $reference = $database->getReference('users');
            $snapshot = $reference->getSnapshot();
            $userfb = $snapshot->getValue();
            //
            for($i = 0; $i<count($arrayIds); $i++){
                foreach ($userfb as $key => $usfb) { 
                    if($arrayIds[$i][0]->userIdcomprador == $key){
                        $object = (object) [
                            'ordenid' => $data[$i]->id,
                            'ordentitle' => $data[$i]->numero,
                            'fechaentrega' => $data[$i]->fechaentrega,
                            'precio' => $data[$i]->total,
                            'comprador' => array_values($usfb)[0],
                            'estado' => $data[$i]->Estados
                        ];
                        array_push($arrayData, $object);
                    }        
                }
            }
            return response()->json($arrayData); 
        } else {
            return false;
        }               
    }
    public function show2($id_firebase, $idioma){
        // Firebaseb conect
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/expertify-3b3d4-firebase-adminsdk-l30jf-1e53428b24.json');
        $firebase = (new Factory)
            ->withServiceAccount($serviceAccount)
            ->withDatabaseUri('https://expertify-3b3d4.firebaseio.com/')
            ->create();
        $database = $firebase->getDatabase();
        // 
        // variables
        $userIdcomprador;
        $data = DB::table('ordenestados')
            ->join('ordencambiaestados', 'ordenestados.id', '=', 'ordencambiaestados.ordenestadoId')
            ->join('ordens', 'ordens.id', '=', 'ordencambiaestados.ordenId')
            ->join('transaccions', 'transaccions.ordenId', '=', 'ordens.id')
            ->join('usuarios', 'usuarios.id', '=', 'transaccions.userIdvendedor')
            ->join('pagos', 'pagos.ordenId', '=', 'ordens.id')
            ->select('ordens.id', 'ordens.numero', 'ordens.fechaentrega', 'ordens.descripcion as ordendescripcion', 'ordens.total','transaccions.userIdcomprador', DB::raw('(SELECT ordenestados.descripcion FROM ordenestados WHERE ordenestados.id = MAX(ordencambiaestados.ordenestadoId)) AS descripcion'), DB::raw('(SELECT traduccions.descripcion FROM ordenestados INNER JOIN valuesidiomas ON ordenestados.validiomaId = valuesidiomas.id INNER JOIN traduccions ON traduccions.validiomaId = valuesidiomas.id INNER JOIN idiomas ON traduccions.idiomaId = idiomas.id WHERE idiomas.id = "'.$idioma.'" and ordenestados.id = MAX(ordencambiaestados.ordenestadoId)) AS traduccion'))
            ->where('usuarios.id_firebase', $id_firebase)
            ->groupBy('ordens.id')
            ->orderBy('ordens.fechaentrega', 'DESC')
            ->get();               
        if($data){
            $arrayIds = array();
            foreach ($data as $key => $dt) {
                $userIdcomprador = DB::table('usuarios')
                    ->select('usuarios.id_firebase as userIdcomprador')
                    ->where('usuarios.id', $dt->userIdcomprador)
                    ->get();
                array_push($arrayIds, $userIdcomprador);    
            }
            $arrayData = array();
            // firebase
            $reference = $database->getReference('users');
            $snapshot = $reference->getSnapshot();
            $userfb = $snapshot->getValue();
            //
            $thumbImg;
            $name;
            for($i = 0; $i<count($arrayIds); $i++){
                foreach ($userfb as $key => $usfb) { 
                    if($arrayIds[$i][0]->userIdcomprador == $key){
                        for($j = 0; $j<count($usfb); $j++){
                            if(array_keys($usfb)[$j] == 'photo'){
                                $thumbImg = array_values($usfb)[$j];
                            }
                            if(array_keys($usfb)[$j] == 'name'){
                                $name = array_values($usfb)[$j];
                            }    
                        }
                        $object = (object) [
                            'ordenid' => $data[$i]->id,
                            'ordentitle' => $data[$i]->numero,
                            'fechaentrega' => $data[$i]->fechaentrega,
                            'ordendescripcion' => $data[$i]->ordendescripcion,
                            'total' => $data[$i]->total,
                            'comprador' => $name,
                            'thumbImg' => $thumbImg ,
                            'estado' => $data[$i]->descripcion,
                            'traduccion' => $data[$i]->traduccion
                        ];

                        array_push($arrayData, $object);
                    }        
                }
            }
            return response()->json($arrayData); 
        } else {
            return false;
        }         
    }
    public function show2_1(Request $request){
        $request->validate([
            'id_firebase' => 'required',
            'page' => 'required',
            'items' => 'required',
            'idioma' => 'required',
        ]);
        $id_firebase = $request->id_firebase;
        $page = $request->page;
        $items = $request->items;
        $idioma = $request->idioma;
        $busqueda = $request->busqueda;
        // Firebaseb conect
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/expertify-3b3d4-firebase-adminsdk-l30jf-1e53428b24.json');
        $firebase = (new Factory)
            ->withServiceAccount($serviceAccount)
            ->withDatabaseUri('https://expertify-3b3d4.firebaseio.com/')
            ->create();
        $database = $firebase->getDatabase();
        // 
        // variables
        $userIdcomprador;
        //paginacion
        $pageskip = intval($page) - 1;
        $items = intval($items);
        $datacount = DB::table('ordenestados')
            ->join('ordencambiaestados', 'ordenestados.id', '=', 'ordencambiaestados.ordenestadoId')
            ->join('ordens', 'ordens.id', '=', 'ordencambiaestados.ordenId')
            ->join('transaccions', 'transaccions.ordenId', '=', 'ordens.id')
            ->join('usuarios', 'usuarios.id', '=', 'transaccions.userIdvendedor')
            ->join('pagos', 'pagos.ordenId', '=', 'ordens.id')
            ->select('ordens.id', 'ordens.numero', 'ordens.fechaentrega', 'ordens.descripcion as ordendescripcion', 'ordens.total','transaccions.userIdcomprador', DB::raw('(SELECT ordenestados.descripcion FROM ordenestados WHERE ordenestados.id = MAX(ordencambiaestados.ordenestadoId)) AS descripcion'), DB::raw('(SELECT traduccions.descripcion FROM ordenestados INNER JOIN valuesidiomas ON ordenestados.validiomaId = valuesidiomas.id INNER JOIN traduccions ON traduccions.validiomaId = valuesidiomas.id INNER JOIN idiomas ON traduccions.idiomaId = idiomas.id WHERE idiomas.id = "'.$idioma.'" and ordenestados.id = MAX(ordencambiaestados.ordenestadoId)) AS traduccion'))
            ->where('usuarios.id_firebase', $id_firebase)
            ->groupBy('ordens.id')
            ->orderBy('ordens.fechaentrega', 'DESC')
            ->get(); 
        $data = DB::table('ordenestados')
            ->join('ordencambiaestados', 'ordenestados.id', '=', 'ordencambiaestados.ordenestadoId')
            ->join('ordens', 'ordens.id', '=', 'ordencambiaestados.ordenId')
            ->join('transaccions', 'transaccions.ordenId', '=', 'ordens.id')
            ->join('usuarios', 'usuarios.id', '=', 'transaccions.userIdvendedor')
            ->join('pagos', 'pagos.ordenId', '=', 'ordens.id')
            ->select('ordens.id', 'ordens.numero', 'ordens.fechaentrega', 'ordens.descripcion as ordendescripcion', 'ordens.total','transaccions.userIdcomprador', DB::raw('(SELECT ordenestados.descripcion FROM ordenestados WHERE ordenestados.id = MAX(ordencambiaestados.ordenestadoId)) AS descripcion'), DB::raw('(SELECT traduccions.descripcion FROM ordenestados INNER JOIN valuesidiomas ON ordenestados.validiomaId = valuesidiomas.id INNER JOIN traduccions ON traduccions.validiomaId = valuesidiomas.id INNER JOIN idiomas ON traduccions.idiomaId = idiomas.id WHERE idiomas.id = "'.$idioma.'" and ordenestados.id = MAX(ordencambiaestados.ordenestadoId)) AS traduccion'))
            ->where('usuarios.id_firebase', $id_firebase)
            ->where('ordens.numero', 'like', '%'.$busqueda.'%')
            ->groupBy('ordens.id')
            ->orderBy('ordens.fechaentrega', 'DESC')
            //->take($items)
            //->skip($pageskip)
            ->limit($items)
            ->offset(($pageskip) * $items)
            ->get();               
        if($data){
            $arrayIds = array();
            foreach ($data as $key => $dt) {
                $userIdcomprador = DB::table('usuarios')
                    ->select('usuarios.id_firebase as userIdcomprador')
                    ->where('usuarios.id', $dt->userIdcomprador)
                    ->get();
                array_push($arrayIds, $userIdcomprador);    
            }
            $arrayData = array();
            $arrayDataandcount = array();
            $totalitems = $datacount->count();
            // firebase
            $reference = $database->getReference('users');
            $snapshot = $reference->getSnapshot();
            $userfb = $snapshot->getValue();
            //
            $thumbImg;
            $name;
            for($i = 0; $i<count($arrayIds); $i++){
                foreach ($userfb as $key => $usfb) { 
                    if($arrayIds[$i][0]->userIdcomprador == $key){
                        for($j = 0; $j<count($usfb); $j++){
                            if(array_keys($usfb)[$j] == 'photo'){
                                $thumbImg = array_values($usfb)[$j];
                            }
                            if(array_keys($usfb)[$j] == 'name'){
                                $name = array_values($usfb)[$j];
                            }    
                        }
                        if($busqueda == ''){
                            $object = (object) [
                                'ordenid' => $data[$i]->id,
                                'ordentitle' => $data[$i]->numero,
                                'fechaentrega' => $data[$i]->fechaentrega,
                                'ordendescripcion' => $data[$i]->ordendescripcion,
                                'total' => $data[$i]->total,
                                'comprador' => $name,
                                'thumbImg' => $thumbImg ,
                                'estado' => $data[$i]->descripcion,
                                'traduccion' => $data[$i]->traduccion
                            ];
                            array_push($arrayData, $object);
                        }else{
                            if(strpos(strtoupper($name),strtoupper($busqueda)) || strpos(strtoupper($data[$i]->numero),strtoupper($busqueda)) !== false) { 
                                $object = (object) [
                                    'ordenid' => $data[$i]->id,
                                    'ordentitle' => $data[$i]->numero,
                                    'fechaentrega' => $data[$i]->fechaentrega,
                                    'ordendescripcion' => $data[$i]->ordendescripcion,
                                    'total' => $data[$i]->total,
                                    'comprador' => $name,
                                    'thumbImg' => $thumbImg ,
                                    'estado' => $data[$i]->descripcion,
                                    'traduccion' => $data[$i]->traduccion
                                ];
                                array_push($arrayData, $object);
                            } 
                        }
                           
                    }        
                }
            }
            $nextpage = $page+1;
            $previouspage =  $page-1;
            if($previouspage == 0){
                $previouspage = 1;
            }
            $lastobject = (object) [
                'count' => $totalitems,
                'next' => 'https://apolomultimedia-server4.info/listado_ordenes2/?id_firebase='.$id_firebase.'&page='.$nextpage.'&items='.$items.'&idioma='.$idioma.'&busqueda='.$busqueda,
                'previous' => 'https://apolomultimedia-server4.info/listado_ordenes2/?id_firebase='.$id_firebase.'&page='.$previouspage.'&items='.$items.'&idioma='.$idioma.'&busqueda='.$busqueda,
                'results' => $arrayData,
            ];
            array_push($arrayDataandcount,$lastobject);
            return response()->json($arrayDataandcount); 
        } else {
            return false;
        }         
    }
    public function show3($id_firebase,$ordenid){
        // Firebaseb conect
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/expertify-3b3d4-firebase-adminsdk-l30jf-1e53428b24.json');
        $firebase = (new Factory)
            ->withServiceAccount($serviceAccount)
            ->withDatabaseUri('https://expertify-3b3d4.firebaseio.com/')
            ->create();
        $database = $firebase->getDatabase();
        // 
        // variables
        $object;
        $useridVendedor;
        $userIdcomprador;
        $usernameVendedor;
        $usernamecomprador;
        $entregado = '';
        $fechaentregado = '';
        $recibido = '';
        $fecharecibido = '';
        $data = DB::table('ordenestados')
            ->join('ordencambiaestados', 'ordenestados.id', '=', 'ordencambiaestados.ordenestadoId')
            ->join('ordens', 'ordens.id', '=', 'ordencambiaestados.ordenId')
            ->join('transaccions', 'transaccions.ordenId', '=', 'ordens.id')
            ->join('usuarios', 'usuarios.id', '=', 'transaccions.userIdvendedor')
            ->join('pagos', 'pagos.ordenId', '=', 'ordens.id')
            ->join('businesses', 'businesses.userId', '=', 'usuarios.id')
            ->select('ordens.numero', 'ordens.descripcion as ordendescripcion', 'ordens.fechaentrega', 'ordens.total','businesses.descripcion as bussiness', 'transaccions.userIdcomprador', 'transaccions.userIdvendedor','pagos.fecha','ordenestados.descripcion as estadodescripcion','ordencambiaestados.created_at')
            ->where('usuarios.id_firebase', $id_firebase)
            ->where('ordens.id', $ordenid)
            ->get();
        foreach ($data as $key => $dt) {
            if($dt->estadodescripcion == 'Entregado'){
                $entregado = $dt->estadodescripcion;
                $fechaentregado = $dt->created_at;
            }else if($dt->estadodescripcion == 'Recibido'){
                $recibido = $dt->estadodescripcion;
                $fecharecibido = $dt->created_at;
            }    
        }
        // firebase
        $reference = $database->getReference('users');
        $snapshot = $reference->getSnapshot();
        $userfb = $snapshot->getValue();
        //
        foreach ($data as $key => $dt) {
            $useridVendedor = DB::table('usuarios')
                    ->select('usuarios.id_firebase as useridVendedor')
                    ->where('usuarios.id', $dt->userIdvendedor)
                    ->get();
            $userIdcomprador = DB::table('usuarios')
                    ->select('usuarios.id_firebase as userIdcomprador')
                    ->where('usuarios.id', $dt->userIdcomprador)
                    ->get();
            // Firebase
            foreach ($userfb as $key => $usfb) { 
                if($key == $useridVendedor[0]->useridVendedor){
                    $usernameVendedor = array_values($usfb)[0];
                }  elseif ($key == $userIdcomprador[0]->userIdcomprador){
                    $usernamecomprador = array_values($usfb)[0];;
                }      
            }        
            //
            $object = (object) [
                'ordentitle' => $dt->numero,
                'producto/servicio' => $dt->ordendescripcion,
                'fechaentrega' => $dt->fechaentrega,
                'precio' => $dt->total,
                'idFirebasevendedor' => $useridVendedor[0]->useridVendedor,
                'negocio/profesional' => $dt->bussiness,
                'idFirebasecliente' => $userIdcomprador[0]->userIdcomprador,
                'cliente' => $usernamecomprador,
                'pago' => $dt->fecha,
                //'marcadoEntregado' => $entregado,
                'fechaentregado' => $fechaentregado,
                //'marcadoRecibido' => $recibido,
                'fecharecibido' => $fecharecibido
            ];   
        }
        if(isset($object)){
            return response()->json($object);
        }else{
            return response()->json(false);
        } 
    }
    public function show4($id_firebase1,$id_firebase2,$idioma){
        $results = DB::select( DB::raw('select transaccions.ordenId, MAX(ordencambiaestados.ordenestadoId) AS Estados FROM `transaccions` INNER JOIN usuarios AS uservendedortable ON uservendedortable.id=transaccions.userIdvendedor AND ( uservendedortable.id_firebase="'.$id_firebase1.'" or uservendedortable.id_firebase="'.$id_firebase2.'") JOIN usuarios AS usercompradortable ON usercompradortable.id=transaccions.userIdcomprador AND (usercompradortable.id_firebase="'.$id_firebase2.'" or usercompradortable.id_firebase="'.$id_firebase1.'") INNER JOIN ordencambiaestados ON transaccions.ordenId=ordencambiaestados.ordenId GROUP by transaccions.ordenId HAVING COUNT(ordencambiaestados.ordenestadoId)=2;') );   
        if($results){
            $data2 = DB::table('traduccions')
                ->join('valuesidiomas', 'traduccions.validiomaId', '=', 'valuesidiomas.id')
                ->join('idiomas', 'traduccions.idiomaId', '=', 'idiomas.id')
                ->select('traduccions.descripcion')
                ->where('idiomas.id', $idioma)
                ->where('valuesidiomas.id', '14')
                ->get();
            return $data2;    
        }else{
            return response()->json(false);
        }
         
    }
    public function show5($id_firebase, $idioma){
        // Firebaseb conect
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/expertify-3b3d4-firebase-adminsdk-l30jf-1e53428b24.json');
        $firebase = (new Factory)
            ->withServiceAccount($serviceAccount)
            ->withDatabaseUri('https://expertify-3b3d4.firebaseio.com/')
            ->create();
        $database = $firebase->getDatabase();
        // 
        // variables
        $userIdvendedor;
        $data = DB::table('ordenestados')
            ->join('ordencambiaestados', 'ordenestados.id', '=', 'ordencambiaestados.ordenestadoId')
            ->join('ordens', 'ordens.id', '=', 'ordencambiaestados.ordenId')
            ->join('transaccions', 'transaccions.ordenId', '=', 'ordens.id')
            ->join('usuarios', 'usuarios.id', '=', 'transaccions.userIdcomprador')
            ->join('pagos', 'pagos.ordenId', '=', 'ordens.id')
            ->select('ordens.id', 'ordens.numero', 'ordens.fechaentrega', 'ordens.descripcion as ordendescripcion', 'ordens.total','transaccions.userIdvendedor', DB::raw('(SELECT ordenestados.descripcion FROM ordenestados WHERE ordenestados.id = MAX(ordencambiaestados.ordenestadoId)) AS descripcion'), DB::raw('(SELECT traduccions.descripcion FROM ordenestados INNER JOIN valuesidiomas ON ordenestados.validiomaId = valuesidiomas.id INNER JOIN traduccions ON traduccions.validiomaId = valuesidiomas.id INNER JOIN idiomas ON traduccions.idiomaId = idiomas.id WHERE idiomas.id = "'.$idioma.'" and ordenestados.id = MAX(ordencambiaestados.ordenestadoId)) AS traduccion'))
            ->where('usuarios.id_firebase', $id_firebase)
            ->groupBy('ordens.id')
            ->orderBy('ordens.fechaentrega', 'DESC')
            ->get();               
        if($data){
            $arrayIds = array();
            foreach ($data as $key => $dt) {
                $userIdvendedor = DB::table('usuarios')
                    ->select('usuarios.id_firebase as userIdvendedor')
                    ->where('usuarios.id', $dt->userIdvendedor)
                    ->get();
                array_push($arrayIds, $userIdvendedor);    
            }
            $arrayData = array();
            // firebase
            $reference = $database->getReference('users');
            $snapshot = $reference->getSnapshot();
            $userfb = $snapshot->getValue();
            //
            $thumbImg;
            $name;
            for($i = 0; $i<count($arrayIds); $i++){
                foreach ($userfb as $key => $usfb) { 
                    if($arrayIds[$i][0]->userIdvendedor == $key){
                        for($j = 0; $j<count($usfb); $j++){
                            if(array_keys($usfb)[$j] == 'photo'){
                                $thumbImg = array_values($usfb)[$j];
                            }
                            if(array_keys($usfb)[$j] == 'name'){
                                $name = array_values($usfb)[$j];
                            }    
                        }
                        $object = (object) [
                            'ordenid' => $data[$i]->id,
                            'ordentitle' => $data[$i]->numero,
                            'fechaentrega' => $data[$i]->fechaentrega,
                            'ordendescripcion' => $data[$i]->ordendescripcion,
                            'total' => $data[$i]->total,
                            'vendedor' => $name,
                            'thumbImg' => $thumbImg,
                            'estado' => $data[$i]->descripcion,
                            'traduccion' => $data[$i]->traduccion
                        ];
                        array_push($arrayData, $object);
                    }        
                }
            }
            return response()->json($arrayData); 
        } else {
            return false;
        }         
    }
    public function show6($id_firebase,$ordenid){
        // Firebaseb conect
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/expertify-3b3d4-firebase-adminsdk-l30jf-1e53428b24.json');
        $firebase = (new Factory)
            ->withServiceAccount($serviceAccount)
            ->withDatabaseUri('https://expertify-3b3d4.firebaseio.com/')
            ->create();
        $database = $firebase->getDatabase();
        // 
        // variables
        $object;
        $useridVendedor;
        $userIdcomprador;
        $usernameVendedor;
        $usernamecomprador;
        $entregado = '';
        $fechaentregado = '';
        $recibido = '';
        $fecharecibido = '';
        $data = DB::table('ordenestados')
            ->join('ordencambiaestados', 'ordenestados.id', '=', 'ordencambiaestados.ordenestadoId')
            ->join('ordens', 'ordens.id', '=', 'ordencambiaestados.ordenId')
            ->join('transaccions', 'transaccions.ordenId', '=', 'ordens.id')
            ->join('usuarios', 'usuarios.id', '=', 'transaccions.userIdcomprador')
            ->join('pagos', 'pagos.ordenId', '=', 'ordens.id')
            ->join('businesses', 'businesses.userId', '=', 'transaccions.userIdvendedor')
            ->select('ordens.numero', 'ordens.descripcion as ordendescripcion', 'ordens.fechaentrega', 'ordens.total','businesses.descripcion as bussiness', 'transaccions.userIdcomprador', 'transaccions.userIdvendedor','pagos.fecha','ordenestados.descripcion as estadodescripcion','ordencambiaestados.created_at')
            ->where('usuarios.id_firebase', $id_firebase)
            ->where('ordens.id', $ordenid)
            ->get();
        
        
        foreach ($data as $key => $dt) {
            if($dt->estadodescripcion == 'Entregado'){
                $entregado = $dt->estadodescripcion;
                $fechaentregado = $dt->created_at;
            }else if($dt->estadodescripcion == 'Recibido'){
                $recibido = $dt->estadodescripcion;
                $fecharecibido = $dt->created_at;
            }    
        }
        // firebase
        $reference = $database->getReference('users');
        $snapshot = $reference->getSnapshot();
        $userfb = $snapshot->getValue();
        //
        foreach ($data as $key => $dt) {
            $useridVendedor = DB::table('usuarios')
                    ->select('usuarios.id_firebase as useridVendedor')
                    ->where('usuarios.id', $dt->userIdvendedor)
                    ->get();
            $userIdcomprador = DB::table('usuarios')
                    ->select('usuarios.id_firebase as userIdcomprador')
                    ->where('usuarios.id', $dt->userIdcomprador)
                    ->get();
            // Firebase
            foreach ($userfb as $key => $usfb) { 
                if($key == $useridVendedor[0]->useridVendedor){
                    $usernameVendedor = array_values($usfb)[0];
                }  elseif ($key == $userIdcomprador[0]->userIdcomprador){
                    $usernamecomprador = array_values($usfb)[0];;
                }      
            }        
            //
            $object = (object) [
                'ordentitle' => $dt->numero,
                'producto/servicio' => $dt->ordendescripcion,
                'fechaentrega' => $dt->fechaentrega,
                'precio' => $dt->total,
                'idFirebasevendedor' => $useridVendedor[0]->useridVendedor,
                'negocio/profesional' => $dt->bussiness,
                'idFirebasecliente' => $userIdcomprador[0]->userIdcomprador,
                'cliente' => $usernamecomprador,
                'pago' => $dt->fecha,
                //'marcadoEntregado' => $entregado,
                'fechaentregado' => $fechaentregado,
                //'marcadoRecibido' => $recibido,
                'fecharecibido' => $fecharecibido
            ];  
        }
        if(isset($object)){
            return response()->json($object);
        }else{
            return response()->json(false);
        }  
    }
    public function show7($id_firebase, $numero, $idioma){
        // Firebaseb conect
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/expertify-3b3d4-firebase-adminsdk-l30jf-1e53428b24.json');
        $firebase = (new Factory)
            ->withServiceAccount($serviceAccount)
            ->withDatabaseUri('https://expertify-3b3d4.firebaseio.com/')
            ->create();
        $database = $firebase->getDatabase();
        // 
        // variables
        $userIdcomprador;
        $data = DB::table('ordenestados')
            ->join('ordencambiaestados', 'ordenestados.id', '=', 'ordencambiaestados.ordenestadoId')
            ->join('ordens', 'ordens.id', '=', 'ordencambiaestados.ordenId')
            ->join('transaccions', 'transaccions.ordenId', '=', 'ordens.id')
            ->join('usuarios', 'usuarios.id', '=', 'transaccions.userIdvendedor')
            ->join('pagos', 'pagos.ordenId', '=', 'ordens.id')
            ->select('ordens.id', 'ordens.numero', 'ordens.fechaentrega', 'ordens.descripcion as ordendescripcion', 'ordens.total','transaccions.userIdcomprador', DB::raw('(SELECT ordenestados.descripcion FROM ordenestados WHERE ordenestados.id = MAX(ordencambiaestados.ordenestadoId)) AS descripcion'), DB::raw('(SELECT traduccions.descripcion FROM ordenestados INNER JOIN valuesidiomas ON ordenestados.validiomaId = valuesidiomas.id INNER JOIN traduccions ON traduccions.validiomaId = valuesidiomas.id INNER JOIN idiomas ON traduccions.idiomaId = idiomas.id WHERE idiomas.id = "'.$idioma.'" and ordenestados.id = MAX(ordencambiaestados.ordenestadoId)) AS traduccion'))
            ->where('usuarios.id_firebase', $id_firebase)
            ->where('ordens.numero', 'like', '%'.$numero.'%')
            ->groupBy('ordens.id')
            ->orderBy('ordens.fechaentrega', 'DESC')
            ->get();               
        if($data){
            $arrayIds = array();
            foreach ($data as $key => $dt) {
                $userIdcomprador = DB::table('usuarios')
                    ->select('usuarios.id_firebase as userIdcomprador')
                    ->where('usuarios.id', $dt->userIdcomprador)
                    ->get();
                array_push($arrayIds, $userIdcomprador);    
            }
            $arrayData = array();
            // firebase
            $reference = $database->getReference('users');
            $snapshot = $reference->getSnapshot();
            $userfb = $snapshot->getValue();
            //
            $thumbImg;
            $name;
            for($i = 0; $i<count($arrayIds); $i++){
                foreach ($userfb as $key => $usfb) { 
                    if($arrayIds[$i][0]->userIdcomprador == $key){
                        for($j = 0; $j<count($usfb); $j++){
                            if(array_keys($usfb)[$j] == 'photo'){
                                $thumbImg = array_values($usfb)[$j];
                            }
                            if(array_keys($usfb)[$j] == 'name'){
                                $name = array_values($usfb)[$j];
                            }    
                        }
                        $object = (object) [
                            'ordenid' => $data[$i]->id,
                            'ordentitle' => $data[$i]->numero,
                            'fechaentrega' => $data[$i]->fechaentrega,
                            'ordendescripcion' => $data[$i]->ordendescripcion,
                            'total' => $data[$i]->total,
                            'comprador' => $name,
                            'thumbImg' => $thumbImg ,
                            'estado' => $data[$i]->descripcion,
                            'traduccion' => $data[$i]->traduccion
                        ];

                        array_push($arrayData, $object);
                    }        
                }
            }
            return response()->json($arrayData); 
        } else {
            return false;
        }         
    }
    public function show8($id_firebase, $username, $idioma){
        // Firebaseb conect
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/expertify-3b3d4-firebase-adminsdk-l30jf-1e53428b24.json');
        $firebase = (new Factory)
            ->withServiceAccount($serviceAccount)
            ->withDatabaseUri('https://expertify-3b3d4.firebaseio.com/')
            ->create();
        $database = $firebase->getDatabase();
        // 
        // variables
        $userIdcomprador;
        $data = DB::table('ordenestados')
            ->join('ordencambiaestados', 'ordenestados.id', '=', 'ordencambiaestados.ordenestadoId')
            ->join('ordens', 'ordens.id', '=', 'ordencambiaestados.ordenId')
            ->join('transaccions', 'transaccions.ordenId', '=', 'ordens.id')
            ->join('usuarios', 'usuarios.id', '=', 'transaccions.userIdvendedor')
            ->join('pagos', 'pagos.ordenId', '=', 'ordens.id')
            ->select('ordens.id', 'ordens.numero', 'ordens.fechaentrega', 'ordens.descripcion as ordendescripcion', 'ordens.total','transaccions.userIdcomprador', DB::raw('(SELECT ordenestados.descripcion FROM ordenestados WHERE ordenestados.id = MAX(ordencambiaestados.ordenestadoId)) AS descripcion'), DB::raw('(SELECT traduccions.descripcion FROM ordenestados INNER JOIN valuesidiomas ON ordenestados.validiomaId = valuesidiomas.id INNER JOIN traduccions ON traduccions.validiomaId = valuesidiomas.id INNER JOIN idiomas ON traduccions.idiomaId = idiomas.id WHERE idiomas.id = "'.$idioma.'" and ordenestados.id = MAX(ordencambiaestados.ordenestadoId)) AS traduccion'))
            ->where('usuarios.id_firebase', $id_firebase)
            ->groupBy('ordens.id')
            ->orderBy('ordens.fechaentrega', 'DESC')
            ->get();               
        if($data){
            $arrayIds = array();
            foreach ($data as $key => $dt) {
                $userIdcomprador = DB::table('usuarios')
                    ->select('usuarios.id_firebase as userIdcomprador')
                    ->where('usuarios.id', $dt->userIdcomprador)
                    ->get();
                array_push($arrayIds, $userIdcomprador);    
            }
            $arrayData = array();
            // firebase
            $reference = $database->getReference('users');
            $snapshot = $reference->getSnapshot();
            $userfb = $snapshot->getValue();
            //
            $thumbImg;
            $name;
            for($i = 0; $i<count($arrayIds); $i++){
                foreach ($userfb as $key => $usfb) { 
                    if($arrayIds[$i][0]->userIdcomprador == $key){
                        for($j = 0; $j<count($usfb); $j++){
                            if(array_keys($usfb)[$j] == 'photo'){
                                $thumbImg = array_values($usfb)[$j];
                            }
                            if(array_keys($usfb)[$j] == 'name'){
                                $name = array_values($usfb)[$j];
                            }    
                        }
                        //if(strcmp(strtoupper($name),strtoupper($username)) == 0) {
                        if(strpos(strtoupper($name),strtoupper($username)) !== false) {    
                            $object = (object) [
                                'ordenid' => $data[$i]->id,
                                'ordentitle' => $data[$i]->numero,
                                'fechaentrega' => $data[$i]->fechaentrega,
                                'ordendescripcion' => $data[$i]->ordendescripcion,
                                'total' => $data[$i]->total,
                                'comprador' => $name,
                                'thumbImg' => $thumbImg ,
                                'estado' => $data[$i]->descripcion,
                                'traduccion' => $data[$i]->traduccion
                            ];
    
                            array_push($arrayData, $object);
                        }
                        
                    }        
                }
            }
            return response()->json($arrayData); 
        } else {
            return false;
        }         
    }
}
