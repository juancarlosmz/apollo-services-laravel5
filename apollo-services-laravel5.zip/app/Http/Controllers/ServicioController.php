<?php
namespace App\Http\Controllers;
use App\Servicio;
use Illuminate\Http\Request;
use App\Http\Requests\ServicioRequest;
use Illuminate\Support\Facades\DB;
class ServicioController extends Controller{
    public function show($idioma){
        $data = DB::table('servicios')
            ->join('valuesidiomas', 'servicios.validiomaId', '=', 'valuesidiomas.id')
            ->join('traduccions', 'traduccions.validiomaId', '=', 'valuesidiomas.id')
            ->join('idiomas', 'traduccions.idiomaId', '=', 'idiomas.id')
            ->select('servicios.id as id', 'traduccions.descripcion as traduccion')
            ->where('idiomas.id', $idioma)
            ->get();
        return $data;
    }
}
