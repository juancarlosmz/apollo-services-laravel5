<?php
namespace App\Http\Controllers;
use App\Transaccion;
use Illuminate\Http\Request;
use App\Http\Requests\TransaccionRequest;
class TransaccionController extends Controller{
    public function create(){
        //
    }
}
