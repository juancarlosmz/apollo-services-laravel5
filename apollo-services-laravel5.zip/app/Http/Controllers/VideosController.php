<?php
namespace App\Http\Controllers;
use App\Videos;
use Illuminate\Http\Request;
use App\Http\Requests\VideosRequest;
use Illuminate\Support\Facades\DB;
// Firebase conection
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Storage;
// vimeo
use Vimeo\Vimeo;
class VideosController extends Controller{
    public function create(Request $request,$id_firebase){
        $userId = DB::table('usuarios')
                ->select('usuarios.id as userId')
                ->where('usuarios.id_firebase', $id_firebase)
                ->get();
        if($userId){
            $objeto = Videos::create([
                'userId' => $userId[0]->userId,
                'titlevideo' => $request->titlevideo,
                'precio' => $request->precio,
                'urlvideo' => $request->urlvideo,
                'urlimagen' => $request->urlimagen
                ]);
            if($objeto){
                return response(200);
            }     
        }
    }
    public function show($id_firebase){
        $userId = DB::table('usuarios')
                ->select('usuarios.id as userId')
                ->where('usuarios.id_firebase', $id_firebase)
                ->get();
        if($userId){
            $objeto = Videos::select('id','titlevideo','precio','urlvideo', 'urlimagen')
                ->where('userId', $userId[0]->userId)
                ->get();
            if($objeto){
                return $objeto;
            }             
        }             
    }
    public function show2($idservicio,$idioma){
        // Firebaseb conect
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/expertify-3b3d4-firebase-adminsdk-l30jf-1e53428b24.json');
        $firebase = (new Factory)
            ->withServiceAccount($serviceAccount)
            ->withDatabaseUri('https://expertify-3b3d4.firebaseio.com/')
            ->create();
        $database = $firebase->getDatabase();
        // 
        if($idservicio == 0){
            $results = DB::select( DB::raw('select videos.titlevideo,videos.urlvideo,videos.urlimagen,videos.precio,videos.userId,businesses.descripcion as business,serviciousuarios.serviciosId,traduccions.descripcion as traduccionservicio, usuarios.id_firebase as firebaseid FROM videos INNER JOIN usuarios ON usuarios.id = videos.userId INNER JOIN businesses ON businesses.userId = usuarios.id INNER JOIN serviciousuarios ON serviciousuarios.userId = usuarios.id INNER JOIN servicios ON servicios.id = serviciousuarios.serviciosId INNER JOIN valuesidiomas ON valuesidiomas.id = servicios.validiomaId INNER JOIN traduccions ON traduccions.validiomaId = valuesidiomas.id INNER JOIN idiomas ON idiomas.id = traduccions.idiomaId WHERE idiomas.id = "'.$idioma.'"') );   
        }else{
            $results = DB::select( DB::raw('select videos.titlevideo,videos.urlvideo,videos.urlimagen,videos.precio,videos.userId,businesses.descripcion as business,serviciousuarios.serviciosId,traduccions.descripcion as traduccionservicio, usuarios.id_firebase as firebaseid FROM videos INNER JOIN usuarios ON usuarios.id = videos.userId INNER JOIN businesses ON businesses.userId = usuarios.id INNER JOIN serviciousuarios ON serviciousuarios.userId = usuarios.id INNER JOIN servicios ON servicios.id = serviciousuarios.serviciosId INNER JOIN valuesidiomas ON valuesidiomas.id = servicios.validiomaId INNER JOIN traduccions ON traduccions.validiomaId = valuesidiomas.id INNER JOIN idiomas ON idiomas.id = traduccions.idiomaId WHERE idiomas.id = "'.$idioma.'" and serviciousuarios.serviciosId = "'.$idservicio.'";') );   
        }
        
        if($results){
            // firebase presence
            $reference = $database->getReference('presence');
            $snapshot = $reference->getSnapshot();
            $presence = $snapshot->getValue();
            // firebase users
            $reference2 = $database->getReference('users');
            $snapshot2 = $reference2->getSnapshot();
            $userfb = $snapshot2->getValue();
            $thumbImg;
            $timestatus;
            $arrayData = array();
            for($i = 0; $i<count($results); $i++){
                foreach ($presence as $key => $prec) { 
                    if($results[$i]->firebaseid == $key){
                        foreach ($userfb as $key => $usfb) { 
                            if($results[$i]->firebaseid == $key){
                                for($j = 0; $j<count($usfb); $j++){
                                    if(array_keys($usfb)[$j] == 'photo'){
                                        $thumbImg = array_values($usfb)[$j];
                                    }
                                }   
                            }        
                        }
                        $object = (object) [
                            'titlevideo' => $results[$i]->titlevideo,
                            'business' => $results[$i]->business,
                            'urlvideo' => $results[$i]->urlvideo,
                            'urlimagen' => $results[$i]->urlimagen,
                            'precio' => $results[$i]->precio,
                            //'userId' => $results[$i]->userId,
                            'serviciosId' => $results[$i]->serviciosId,
                            'traduccionservicio' => $results[$i]->traduccionservicio,
                            'firebaseid' => $results[$i]->firebaseid,
                            'timestatus' => $prec,
                            'photo' => $thumbImg,
                        ];
                        array_push($arrayData, $object);
                    }   
                }
            }
            return response()->json($arrayData);  
        }else{
            return response()->json(false);
        }
    }
    public function show2_1($idservicio,$idioma){
        // vimeo conexion
        $client = new Vimeo("775c22cdd9fc4659ce5e3d8b60983ea494d5f651", "EvxF5vcxCLcmYDoTdY14Je1WuDG7fVolfehkXEOi9ZtkWr1NXcrCwmdlrOSYj6uwKwkFvZGHRXmHW8NzD8ub5wNItDpoQBbs062//5f+8FNWUnXU2sxrOJrdjMUpqJ9a", "34e804b0ff350b833660a390045af984");
        $response = $client->request('/me/videos', array(), 'GET');
        $datavimeo = $response['body']['data'];
        $arrayVimeo = array();

        // Firebaseb conect
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/expertify-3b3d4-firebase-adminsdk-l30jf-1e53428b24.json');
        $firebase = (new Factory)
            ->withServiceAccount($serviceAccount)
            ->withDatabaseUri('https://expertify-3b3d4.firebaseio.com/')
            ->create();
        $database = $firebase->getDatabase();
        // 
        if($idservicio == 0){
            $results = DB::select( DB::raw('select videos.titlevideo,videos.urlvideo,videos.urlimagen,videos.precio,videos.userId,businesses.descripcion as business,serviciousuarios.serviciosId,traduccions.descripcion as traduccionservicio, usuarios.id_firebase as firebaseid FROM videos INNER JOIN usuarios ON usuarios.id = videos.userId INNER JOIN businesses ON businesses.userId = usuarios.id INNER JOIN serviciousuarios ON serviciousuarios.userId = usuarios.id INNER JOIN servicios ON servicios.id = serviciousuarios.serviciosId INNER JOIN valuesidiomas ON valuesidiomas.id = servicios.validiomaId INNER JOIN traduccions ON traduccions.validiomaId = valuesidiomas.id INNER JOIN idiomas ON idiomas.id = traduccions.idiomaId WHERE idiomas.id = "'.$idioma.'"') );   
        }else{
            $results = DB::select( DB::raw('select videos.titlevideo,videos.urlvideo,videos.urlimagen,videos.precio,videos.userId,businesses.descripcion as business,serviciousuarios.serviciosId,traduccions.descripcion as traduccionservicio, usuarios.id_firebase as firebaseid FROM videos INNER JOIN usuarios ON usuarios.id = videos.userId INNER JOIN businesses ON businesses.userId = usuarios.id INNER JOIN serviciousuarios ON serviciousuarios.userId = usuarios.id INNER JOIN servicios ON servicios.id = serviciousuarios.serviciosId INNER JOIN valuesidiomas ON valuesidiomas.id = servicios.validiomaId INNER JOIN traduccions ON traduccions.validiomaId = valuesidiomas.id INNER JOIN idiomas ON idiomas.id = traduccions.idiomaId WHERE idiomas.id = "'.$idioma.'" and serviciousuarios.serviciosId = "'.$idservicio.'";') );   
        }
        
        if($results){
            // firebase presence
            $reference = $database->getReference('presence');
            $snapshot = $reference->getSnapshot();
            $presence = $snapshot->getValue();
            // firebase users
            $reference2 = $database->getReference('users');
            $snapshot2 = $reference2->getSnapshot();
            $userfb = $snapshot2->getValue();
            $thumbImg;
            $timestatus;
            $arrayData = array();
            for($i = 0; $i<count($results); $i++){
                foreach ($presence as $key => $prec) { 
                    if($results[$i]->firebaseid == $key){
                        foreach ($userfb as $key => $usfb) { 
                            if($results[$i]->firebaseid == $key){
                                for($j = 0; $j<count($usfb); $j++){
                                    if(array_keys($usfb)[$j] == 'photo'){
                                        $thumbImg = array_values($usfb)[$j]; 
                                    }
                                }   
                            }        
                        }
                        $videovimeo = $datavimeo[$i]['uri'];
                        $idvideovimeo = substr($videovimeo,7,11);

/*
                        foreach ($datavimeo as $keyvim => $vim) {
                            $videovimeo = $datavimeo[$keyvim]['uri'];
                        }*/
                        $object = (object) [
                            'titlevideo' => $results[$i]->titlevideo,
                            'business' => $results[$i]->business,
                            'urlvideo' => $results[$i]->urlvideo,
                            'urlvideo' => $results[$i]->urlvideo,
                            'videovimeo' => 'https://player.vimeo.com/video'.$idvideovimeo,
                            'urlimagen' => $results[$i]->urlimagen,
                            'precio' => $results[$i]->precio,
                            //'userId' => $results[$i]->userId,
                            'serviciosId' => $results[$i]->serviciosId,
                            'traduccionservicio' => $results[$i]->traduccionservicio,
                            'firebaseid' => $results[$i]->firebaseid,
                            'timestatus' => $prec,
                            'photo' => $thumbImg,
                        ];
                        array_push($arrayData, $object);
                    }   
                }
            }
            return response()->json($arrayData);  
        }else{
            return response()->json(false);
        }




    }
    public function show3(){
        //$client = new Vimeo("{client_id}", "{client_secret}", "{access_token}");
        $client = new Vimeo("775c22cdd9fc4659ce5e3d8b60983ea494d5f651", "EvxF5vcxCLcmYDoTdY14Je1WuDG7fVolfehkXEOi9ZtkWr1NXcrCwmdlrOSYj6uwKwkFvZGHRXmHW8NzD8ub5wNItDpoQBbs062//5f+8FNWUnXU2sxrOJrdjMUpqJ9a", "34e804b0ff350b833660a390045af984");
        $response = $client->request('/me/videos', array(), 'GET');
        $data = $response['body']['data'];
        $arrayVimeo = array();
        return response()->json($data);
        foreach ($data as $keyvim => $vim) {
            $objectvimeo = (object) [
                'videoVimeo' => $data[$keyvim]['embed']['html'],
            ];
            array_push($arrayVimeo, $objectvimeo);
        }
        return response()->json($arrayVimeo);
    }
    
    public function update(Request $request, $id){
        $objeto = Videos::findOrFail($id);
        $objeto->fill($request->all());
        $objeto->push();
        if($objeto){
            return response(200);
        }
    }
    public function destroy($id){
        $objeto = Videos::findOrFail($id);
        $objeto->delete();
        if($objeto){
            return response(200);
        }
    }
}
