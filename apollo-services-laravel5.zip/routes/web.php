<?php
Route::get('userfb','FirebaseController@index');

// servicios servicio
Route::get('servicio/{idioma}','ServicioController@show');

// servicios usuario
Route::get('usuarioservicio/{id_firebase}','UsuarioController@show');
Route::get('listarusuario/{id_firebase}','UsuarioController@show2');
Route::post('usuario','UsuarioController@create');
Route::post('usuarioservicio','UsuarioController@create2');
Route::put('usuario/{id_firebase}','UsuarioController@update');
/*Route::put('usuarioservicio/{id_firebase}','UsuarioController@update2');*/

// servicios cuenta bancaria
Route::get('cuentabancaria/{id_firebase}','CuentabancariaController@show');
Route::post('cuentabancaria/{id_firebase}','CuentabancariaController@create');
Route::put('cuentabancaria/{id_firebase}','CuentabancariaController@update');

// servicios pago
Route::post('pago','PagoController@create');
Route::post('transaccion','PagoController@create2');
Route::post('verificarpago','PagoController@create3');

// servicios ordenestado
Route::get('listado_ordenes_pendiente/{id_firebase}','OrdenestadoController@show');
Route::get('listado_ordenes/{id_firebase}/{idioma}','OrdenestadoController@show2');
Route::get('listado_ordenes2','OrdenestadoController@show2_1');
Route::get('verorden/{id_firebase}/{ordenid}','OrdenestadoController@show3');
Route::get('ordenestadovideollamada/{id_firebase1}/{id_firebase2}/{idioma}','OrdenestadoController@show4');
Route::get('listado_pedidos/{id_firebase}/{idioma}','OrdenestadoController@show5');
Route::get('verpedido/{id_firebase}/{ordenid}','OrdenestadoController@show6');
Route::get('busqueda_ordenes/{id_firebase}/{numero}/{idioma}','OrdenestadoController@show7');
Route::get('busqueda_ordenes_username/{id_firebase}/{username}/{idioma}','OrdenestadoController@show8');

// servicios orden
Route::post('orden','OrdenController@create');

// servicios deposito orden
Route::get('depositoorden/{id_firebase}','DepositoordenController@show');

// servicios orden cambia estado
Route::post('ordenestadoentregado/{idioma}','OrdencambiaestadoController@create');
Route::post('ordenestadorecibido/{idioma}','OrdencambiaestadoController@create2');

// servicios videos
Route::get('videos/{id_firebase}','VideosController@show');
Route::get('allvideos/{idservicio}/{idioma}','VideosController@show2');
Route::get('allvideos2/{idservicio}/{idioma}','VideosController@show2_1');
Route::get('vimeo','VideosController@show3');
Route::post('videos/{id_firebase}','VideosController@create');
Route::put('videos/{id}','VideosController@update');
Route::delete('videos/{id}','VideosController@destroy');

// servicios de Traducciones
Route::get('traduccion/{idioma}','TraduccionController@show');

Route::get('/', function () {
    return view('welcome');
});
